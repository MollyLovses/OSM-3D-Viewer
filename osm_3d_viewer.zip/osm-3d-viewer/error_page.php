<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Cute 403 Error - Forbidden</title>
  <link rel="icon" href="./app-assets/img/pics/chan.png">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      margin: 0;
      background-color: #E7BCDE;
      background-image: linear-gradient(45deg, #FED9ED 0%, #E7BCDE 99%, #E7BCDE 100%);
    }

    .error-container {
      text-align: center;
      background-color: #fff;
      padding: 20px;
      border-radius: 15px;
      box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
      max-width: 80%;
      width: 300px; /* Adjust width as needed for larger screens */
    }

    h1 {
      font-size: 2.5rem;
      color: #E7BCDE;
      margin-bottom: 15px;
    }

    p {
      font-size: 1.2rem;
      color: #333;
      margin-bottom: 20px;
    }

    .cute-image {
      width: 200px;
      height: auto;
      border-radius: 50%;
      margin-bottom: 20px;
      transition: transform 0.5s ease-in-out;
    }

    .cute-image:hover {
      transform: scale(1.1);
    }

    .heart {
      color: #E7BCDE;
      font-size: 1.5rem;
      animation: heartbeat 1.5s infinite;
      display: inline-block;
    }

    @keyframes heartbeat {
      0% {
        transform: scale(1);
      }
      50% {
        transform: scale(1.3);
      }
      100% {
        transform: scale(1);
      }
    }
  </style>
</head>
<body>
  <div class="error-container">
    <img src="./app-assets/img/pics/error403.jpg" alt="Cute Error Image" class="cute-image">
    <h1>403 <br> Forbidden</h1>
    <p>Oops! It seems you're not allowed here. Please go back <span class="heart">&hearts;</span></p>
  </div>
</body>
</html>
